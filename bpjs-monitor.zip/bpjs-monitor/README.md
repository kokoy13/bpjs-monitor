# BPJS Bridging Monitor

Memeriksa 16 endpoint BPJS (VClaim, Antrean RS, Antrean FKTP, Apotek, PCare, i-Care,
eRekamMedis, Aplicares — masing-masing V1 & V2) setiap 5 menit, lalu menampilkannya
di dashboard web.

- Tanpa dependensi: cukup **Node.js ≥ 18**.
- Rincian waktu per cek: **DNS → TCP → TLS → Server (tunggu respons) → Unduh**,
  sehingga terlihat lambatnya di jaringan atau di server BPJS.
- Riwayat disimpan di `data/results.jsonl` (lama simpan diatur `retentionDays` di config.json, saat ini 30 hari), lengkap dengan uptime,
  rata-rata, p95, dan tabel kegagalan.
- Jadwal cek disejajarkan ke jam dinding (:00, :05, :10, …).

## Instalasi (Ubuntu/Debian)

```bash
sudo useradd -r -s /usr/sbin/nologin bpjsmon
sudo mkdir -p /opt/bpjs-monitor && sudo cp -r ./* /opt/bpjs-monitor/
sudo mkdir -p /opt/bpjs-monitor/data && sudo chown -R bpjsmon: /opt/bpjs-monitor

# Login dashboard (sangat disarankan)
sudo tee /etc/bpjs-monitor.env >/dev/null <<'EOF'
DASH_USER=admin
DASH_PASS=ganti-password-ini
EOF
sudo chmod 600 /etc/bpjs-monitor.env

sudo cp bpjs-monitor.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now bpjs-monitor
journalctl -u bpjs-monitor -f
```

Buka `http://IP-SERVER:8080`. Kalau dashboard dipasang di belakang Nginx, cukup
`proxy_pass http://127.0.0.1:8080;`, dan aplikasinya bisa diikat ke localhost dengan
`HOST=127.0.0.1` di file env.

Uji cepat tanpa systemd: `node server.js`

## Dua jenis pengecekan

**1. Cek koneksi (default, tanpa kredensial).** Monitor mengirim `GET` ke base URL.
Hasilnya mengukur DNS, TCP, TLS, dan respons gateway BPJS. Respons 4xx tetap dianggap
**terjangkau**; hanya timeout, error jaringan, dan 5xx yang dihitung **gagal**.
Cek ini **tidak** membuktikan layanan VClaim dan lainnya berfungsi, hanya bahwa
jalurnya hidup.

**2. Cek terotentikasi (opsional).** Monitor memanggil endpoint ringan dengan header
`X-cons-id`, `X-timestamp`, `X-signature`, dan `user_key`. Cara mengaktifkannya:

1. Isi `consId` di `config.json` → `credentials`. Simpan secret dan user_key di
   `/etc/bpjs-monitor.env`, misalnya `BPJS_VCLAIM_SECRET=...` dan
   `BPJS_VCLAIM_USERKEY=...`. Config merujuknya dengan `"env:NAMA_VAR"`.
2. Pada target terkait, isi `"credential": "vclaim"` dan `"probePath"` dengan endpoint
   referensi yang ringan dan aman dipanggil berulang. Contohnya endpoint referensi
   propinsi untuk VClaim atau referensi poli untuk Antrean RS. **Cocokkan path-nya
   dengan katalog WS BPJS versi Anda.**
3. Monitor membaca `metaData.code` dari body. Kode selain `200` ditandai **Peringatan**.
   Isi respons yang terenkripsi tidak didekripsi karena tidak diperlukan untuk cek
   kesehatan.

Catatan: setiap cek terotentikasi = 1 hit ke API produksi BPJS. Dengan interval
5 menit, itu 288 hit/hari per target.

## Konfigurasi (`config.json`)

| Kunci | Default | Arti |
|---|---|---|
| `intervalMinutes` | 5 | Jarak antar cek |
| `timeoutMs` | 30000 | Batas waktu per cek. Dibuat > 10 s supaya latensi asli tetap terlihat, tidak terpotong di 10 s |
| `slowThresholdMs` | 3000 | Di atas nilai ini status = Lambat |
| `retentionDays` | 7 | Lama riwayat disimpan |
| `concurrency` | 4 | Jumlah cek paralel |

## API

- `GET /api/status?hours=24` — data dashboard (JSON)
- `POST /api/check-now` — cek manual (maks 1× per menit)
- `GET /healthz` — untuk monitoring eksternal
