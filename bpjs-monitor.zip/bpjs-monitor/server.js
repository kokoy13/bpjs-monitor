#!/usr/bin/env node
/*
 * BPJS Bridging Monitor
 * Cek berkala endpoint BPJS (VClaim, Antrean, dll) dan tampilkan di dashboard web.
 * Tanpa dependensi eksternal — cukup Node.js >= 18.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const zlib = require('zlib');
const { URL } = require('url');

const CONFIG_PATH = process.env.CONFIG || path.join(__dirname, 'config.json');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'results.jsonl');
const PUBLIC_DIR = path.join(__dirname, 'public');

const cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
const PORT = Number(process.env.PORT || cfg.port || 8080);
const HOST = process.env.HOST || '0.0.0.0';
const INTERVAL_MS = (cfg.intervalMinutes || 5) * 60 * 1000;
const TIMEOUT_MS = cfg.timeoutMs || 30000;
const SLOW_MS = cfg.slowThresholdMs || 3000;
const RETENTION_MS = (cfg.retentionDays || 7) * 24 * 3600 * 1000;
const CONCURRENCY = cfg.concurrency || 4;
const DASH_USER = process.env.DASH_USER || '';
const DASH_PASS = process.env.DASH_PASS || '';

fs.mkdirSync(DATA_DIR, { recursive: true });

// ---------- util ----------
const log = (...a) => console.log(new Date().toISOString(), ...a);

function resolveSecret(v) {
  if (typeof v !== 'string') return '';
  if (v.startsWith('env:')) return process.env[v.slice(4)] || '';
  return v;
}

function getCredential(name) {
  if (!name) return null;
  const c = (cfg.credentials || {})[name];
  if (!c) return null;
  const cred = {
    consId: resolveSecret(c.consId),
    secretKey: resolveSecret(c.secretKey),
    userKey: resolveSecret(c.userKey),
  };
  return cred.consId && cred.secretKey ? cred : null;
}

// Header signature BPJS: HMAC-SHA256(consId + "&" + timestamp, secretKey), base64
function bpjsHeaders(cred) {
  const ts = Math.floor(Date.now() / 1000).toString();
  const sig = crypto.createHmac('sha256', cred.secretKey)
    .update(`${cred.consId}&${ts}`).digest('base64');
  const h = { 'X-cons-id': cred.consId, 'X-timestamp': ts, 'X-signature': sig };
  if (cred.userKey) h.user_key = cred.userKey;
  return h;
}

// ---------- probe ----------
// Mengukur rincian waktu: DNS, TCP connect, TLS handshake, TTFB, total.
function probe(target) {
  return new Promise((resolve) => {
    const cred = getCredential(target.credential);
    const authenticated = !!(cred && target.probePath);
    const urlStr = authenticated
      ? target.baseUrl.replace(/\/+$/, '') + '/' + target.probePath.replace(/^\/+/, '')
      : target.baseUrl;

    const u = new URL(urlStr);
    const lib = u.protocol === 'http:' ? http : https;
    const headers = { 'User-Agent': 'bpjs-bridging-monitor/1.0', Accept: 'application/json' };
    if (authenticated) Object.assign(headers, bpjsHeaders(cred));

    const t0 = process.hrtime.bigint();
    const since = () => Number(process.hrtime.bigint() - t0) / 1e6;
    const tm = {};
    let done = false;
    let body = '';

    const finish = (r) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      const total = since();
      resolve({
        t: Date.now(),
        id: target.id,
        auth: authenticated,
        ms: round(total),
        dns: round(tm.dns),
        tcp: round(tm.tcp),
        tls: round(tm.tls),
        ttfb: round(tm.ttfb),
        ...r,
      });
    };

    // agent:false => koneksi baru tiap cek, supaya DNS/TCP/TLS ikut terukur
    const req = lib.request(u, { method: 'GET', headers, agent: false }, (res) => {
      tm.ttfb = since();
      res.setEncoding('utf8');
      res.on('data', (c) => { if (body.length < 65536) body += c; });
      res.on('end', () => {
        const r = { http: res.statusCode };
        if (isWafRejection(res, body)) {
          r.status = 'blocked';
          r.err = 'Ditolak WAF F5' + (wafSupportId(body) ? ` (support ID ${wafSupportId(body)})` : '');
          return finish(r);
        }
        if (isUpstreamError(res, body)) {
          // F5 terjangkau, tetapi gagal meneruskan ke server BPJS di belakangnya.
          r.status = 'down';
          r.err = 'F5: upstream BPJS tidak terjangkau (' + body.trim().slice(0, 120) + ')';
          return finish(r);
        }
        // Respons BPJS biasanya punya metaData / metadata {code, message}
        try {
          const j = JSON.parse(body);
          const m = j.metaData || j.metadata || j.MetaData;
          if (m) { r.metaCode = String(m.code ?? ''); r.metaMsg = String(m.message ?? '').slice(0, 200); }
        } catch (_) { /* bukan JSON, abaikan */ }
        r.status = classify(r, since());
        finish(r);
      });
      res.on('error', (e) => finish({ status: 'down', err: e.code || e.message }));
    });

    req.on('socket', (s) => {
      s.once('lookup', () => { tm.dns = since(); });
      s.once('connect', () => { tm.tcp = since(); });
      s.once('secureConnect', () => { tm.tls = since(); });
    });
    req.on('error', (e) => {
      // Koneksi diputus tepat setelah TLS selesai, sebelum ada respons HTTP:
      // pola firewall yang menolak path/permintaan, bukan server mati.
      if (e.code === 'ECONNRESET' && tm.tls != null && tm.ttfb == null) {
        return finish({ status: 'blocked', err: 'ECONNRESET setelah TLS (kemungkinan ditolak firewall)' });
      }
      finish({ status: 'down', err: e.code || e.message });
    });

    const timer = setTimeout(() => {
      finish({ status: 'down', err: `TIMEOUT>${TIMEOUT_MS}ms` });
      req.destroy();
    }, TIMEOUT_MS);

    req.end();
  });
}

function round(v) { return v == null ? null : Math.round(v * 10) / 10; }

// Halaman penolakan WAF F5 Distributed Cloud (server: volt-adc).
// Gateway terjangkau, tetapi permintaan tanpa kredensial/path sah ditolak.
function isWafRejection(res, body) {
  const server = String(res.headers.server || '').toLowerCase();
  return server.includes('volt-adc') && /requested URL was rejected/i.test(body);
}

// Galat proxy F5 (Envoy) saat server asal tidak bisa dihubungi.
function isUpstreamError(res, body) {
  const server = String(res.headers.server || '').toLowerCase();
  return server.includes('volt-adc') && res.statusCode >= 500 && /^upstream (connect error|request timeout)|no healthy upstream/i.test(body.trim());
}

function wafSupportId(body) {
  const m = /support ID is\s*([\w-]+)/i.exec(body);
  return m ? m[1] : '';
}

function classify(r, ms) {
  if (r.http >= 500) return 'down';
  // metaCode hanya ada pada cek terotentikasi
  if (r.metaCode && !['200', '1'].includes(r.metaCode)) return 'warn';
  if (ms > SLOW_MS) return 'slow';
  return 'up';
}

// ---------- storage ----------
let results = []; // urut waktu naik

function loadResults() {
  if (!fs.existsSync(DATA_FILE)) return;
  const cutoff = Date.now() - RETENTION_MS;
  const lines = fs.readFileSync(DATA_FILE, 'utf8').split('\n');
  for (const l of lines) {
    if (!l) continue;
    try { const r = JSON.parse(l); if (r.t >= cutoff) results.push(r); } catch (_) {}
  }
  compact();
  log(`Memuat ${results.length} hasil dari ${DATA_FILE}`);
}

function compact() {
  const cutoff = Date.now() - RETENTION_MS;
  results = results.filter((r) => r.t >= cutoff);
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, results.map((r) => JSON.stringify(r)).join('\n') + (results.length ? '\n' : ''));
  fs.renameSync(tmp, DATA_FILE);
}

function saveBatch(batch) {
  results.push(...batch);
  fs.appendFileSync(DATA_FILE, batch.map((r) => JSON.stringify(r)).join('\n') + '\n');
}

// ---------- scheduler ----------
let running = false;
let lastRunAt = null;
let nextRunAt = null;
let lastManualAt = 0;

async function runRound(reason) {
  if (running) { log('Ronde sebelumnya masih jalan, dilewati'); return false; }
  running = true;
  const started = Date.now();
  try {
    const queue = [...cfg.targets];
    const batch = [];
    const worker = async () => {
      while (queue.length) {
        const t = queue.shift();
        batch.push(await probe(t));
      }
    };
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, queue.length) }, worker));
    batch.sort((a, b) => a.t - b.t);
    saveBatch(batch);
    lastRunAt = started;
    const down = batch.filter((r) => r.status === 'down').length;
    log(`Ronde (${reason}) selesai ${Date.now() - started}ms — down: ${down}/${batch.length}`);
  } catch (e) {
    log('Ronde gagal:', e);
  } finally {
    running = false;
  }
  return true;
}

function scheduleNext() {
  // Sejajarkan ke kelipatan interval jam dinding (mis. :00, :05, :10 ...)
  const now = Date.now();
  nextRunAt = Math.ceil((now + 1000) / INTERVAL_MS) * INTERVAL_MS;
  setTimeout(async () => { await runRound('terjadwal'); scheduleNext(); }, nextRunAt - now);
}

// ---------- API ----------
function percentile(arr, p) {
  if (!arr.length) return null;
  const s = [...arr].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.floor((p / 100) * s.length))];
}

// Riwayat untuk grafik kartu dikelompokkan di server ke slot waktu tetap (maks 144),
// supaya ukuran respons tidak tumbuh mengikuti panjang rentang.
// Tiap slot: [waktu cek terburuk, status terburuk, latensi slot, http, err, jumlah cek, jumlah bukan-normal]
const SLOT_RANK = { up: 0, blocked: 0.5, slow: 1, warn: 2, down: 3 };
const MAX_SLOTS = 144;
function buildSlots(rs, start, end, n) {
  const w = (end - start) / n;
  const slots = new Array(n).fill(null);
  for (const r of rs) {
    const k = Math.min(n - 1, Math.floor((r.t - start) / w));
    if (k < 0) continue;
    const rank = SLOT_RANK[r.status] ?? 0;
    const s = slots[k];
    if (!s) { slots[k] = [r.t, r.status, r.ms, r.http ?? null, r.err ?? null, 1, r.status === 'up' ? 0 : 1, rank]; continue; }
    s[5]++; if (r.status !== 'up') s[6]++;
    if (rank > s[7] || (rank === s[7] && r.ms > s[2])) { s[0] = r.t; s[1] = r.status; s[2] = r.ms; s[3] = r.http ?? null; s[4] = r.err ?? null; s[7] = rank; }
  }
  return slots.map((s) => (s ? s.slice(0, 7) : null));
}

function statusPayload(hours) {
  const now = Date.now();
  const since = now - hours * 3600 * 1000;
  const intervalMinutes = cfg.intervalMinutes || 5;
  const nSlots = Math.max(1, Math.min(MAX_SLOTS, Math.round((hours * 60) / intervalMinutes)));
  const byId = new Map(cfg.targets.map((t) => [t.id, []]));
  for (const r of results) if (r.t >= since && byId.has(r.id)) byId.get(r.id).push(r);

  const targets = cfg.targets.map((t) => {
    const rs = byId.get(t.id);
    const latest = rs[rs.length - 1] || null;
    const okMs = rs.filter((r) => r.status !== 'down').map((r) => r.ms);
    const upCount = rs.filter((r) => r.status !== 'down').length;
    return {
      id: t.id, module: t.module, version: t.version, url: t.baseUrl,
      authenticated: !!(getCredential(t.credential) && t.probePath),
      latest,
      stats: {
        checks: rs.length,
        uptime: rs.length ? Math.round((upCount / rs.length) * 1000) / 10 : null,
        avg: okMs.length ? Math.round(okMs.reduce((a, b) => a + b, 0) / okMs.length) : null,
        p95: percentile(okMs, 95),
      },
      slots: buildSlots(rs, since, now, nSlots),
    };
  });

  const failures = results
    .filter((r) => r.t >= since && (r.status === 'down' || r.status === 'warn'))
    .slice(-100).reverse()
    .map((r) => ({ ...r, target: cfg.targets.find((t) => t.id === r.id) }))
    .map((r) => ({ t: r.t, module: r.target?.module, version: r.target?.version, status: r.status,
      http: r.http ?? null, ms: r.ms, err: r.err ?? null, metaCode: r.metaCode ?? null, metaMsg: r.metaMsg ?? null }));

  return {
    now, lastRunAt, nextRunAt, running, retentionDays: Math.round(RETENTION_MS / 86400000),
    intervalMinutes, timeoutMs: TIMEOUT_MS, slowThresholdMs: SLOW_MS,
    hours, targets, failures,
  };
}

// ---------- riwayat (halaman /history) ----------
// Tanggal dibaca sebagai tanggal WIB (UTC+7, tanpa DST).
const WIB_OFFSET_MS = 7 * 3600 * 1000;
function wibDayStart(ymd) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(ymd || '');
  if (!m) return null;
  return Date.UTC(+m[1], +m[2] - 1, +m[3]) - WIB_OFFSET_MS;
}
function wibToday() {
  return new Date(Date.now() + WIB_OFFSET_MS).toISOString().slice(0, 10);
}

function historyPayload(q) {
  const modules = [...new Set(cfg.targets.map((t) => t.module))];
  const module = modules.includes(q.get('module')) ? q.get('module') : modules[0];
  const targets = cfg.targets.filter((t) => t.module === module);
  const versions = targets.map((t) => t.version);
  const version = versions.includes(q.get('version')) ? q.get('version') : '';
  const statuses = ['up', 'slow', 'warn', 'blocked', 'down'];
  const status = statuses.includes(q.get('status')) ? q.get('status') : '';

  const today = wibToday();
  let from = q.get('from') || today;
  let to = q.get('to') || today;
  if (wibDayStart(from) == null) from = today;
  if (wibDayStart(to) == null) to = today;
  if (from > to) [from, to] = [to, from];
  const tFrom = wibDayStart(from);
  const tTo = wibDayStart(to) + 24 * 3600 * 1000; // eksklusif: akhir hari 'to'

  const pageSize = Math.min(500, Math.max(10, Number(q.get('pageSize')) || 50));
  const byId = new Map(targets.map((t) => [t.id, t]));

  // Semua hasil modul ini dalam rentang tanggal (+ versi), terbaru dulu.
  const inRange = [];
  for (let i = results.length - 1; i >= 0; i--) {
    const r = results[i];
    if (r.t < tFrom) break;
    if (r.t >= tTo) continue;
    const t = byId.get(r.id);
    if (!t || (version && t.version !== version)) continue;
    inRange.push([r, t]);
  }
  const ok = inRange.filter(([r]) => r.status !== 'down');
  const counts = Object.fromEntries(statuses.map((s) => [s, 0]));
  for (const [r] of inRange) if (r.status in counts) counts[r.status]++;
  const summary = {
    checks: inRange.length,
    uptime: inRange.length ? Math.round((ok.length / inRange.length) * 1000) / 10 : null,
    avg: ok.length ? Math.round(ok.reduce((a, [r]) => a + r.ms, 0) / ok.length) : null,
    p95: percentile(ok.map(([r]) => r.ms), 95),
    counts,
  };

  const filtered = status ? inRange.filter(([r]) => r.status === status) : inRange;
  const total = filtered.length;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const page = Math.min(pages, Math.max(1, Math.floor(Number(q.get('page')) || 1)));
  const rows = filtered.slice((page - 1) * pageSize, page * pageSize).map(([r, t]) => ({
    t: r.t, version: t.version, url: t.baseUrl, status: r.status, http: r.http ?? null,
    ms: r.ms, dns: r.dns, tcp: r.tcp, tls: r.tls, ttfb: r.ttfb, err: r.err ?? null,
    metaCode: r.metaCode ?? null, metaMsg: r.metaMsg ?? null,
  }));

  // Batas tanggal yang masuk akal = masa retensi data.
  const minDate = new Date(Date.now() - RETENTION_MS + WIB_OFFSET_MS).toISOString().slice(0, 10);
  return { modules, module, versions, version, status, from, to, minDate, maxDate: today,
    page, pageSize, pages, total, summary, rows };
}

function checkAuth(req) {
  if (!DASH_USER) return true;
  const h = req.headers.authorization || '';
  if (!h.startsWith('Basic ')) return false;
  const [u, p] = Buffer.from(h.slice(6), 'base64').toString().split(':');
  const eq = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
  return eq(u || '', DASH_USER) && eq(p || '', DASH_PASS);
}

function send(res, code, type, body) {
  const headers = { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', Vary: 'Accept-Encoding' };
  const accept = String(res.req?.headers['accept-encoding'] || '');
  // Kompres respons teks yang cukup besar bila browser mendukung gzip
  if (body && body.length > 1024 && /\bgzip\b/.test(accept)) {
    body = zlib.gzipSync(body, { level: 6 });
    headers['Content-Encoding'] = 'gzip';
  }
  res.writeHead(code, headers);
  res.end(body);
}

const server = http.createServer((req, res) => {
  if (!checkAuth(req)) {
    res.writeHead(401, { 'WWW-Authenticate': 'Basic realm="BPJS Monitor"' });
    return res.end('Unauthorized');
  }
  const u = new URL(req.url, 'http://x');

  if (req.method === 'GET' && u.pathname === '/api/status') {
    const hours = Math.min(RETENTION_MS / 3600000, Math.max(1, Number(u.searchParams.get('hours')) || 24));
    return send(res, 200, 'application/json', JSON.stringify(statusPayload(hours)));
  }
  if (req.method === 'GET' && u.pathname === '/api/history') {
    return send(res, 200, 'application/json', JSON.stringify(historyPayload(u.searchParams)));
  }
  if (req.method === 'POST' && u.pathname === '/api/check-now') {
    if (running) return send(res, 409, 'application/json', '{"ok":false,"msg":"Pengecekan sedang berjalan"}');
    if (Date.now() - lastManualAt < 60000) return send(res, 429, 'application/json', '{"ok":false,"msg":"Tunggu 1 menit antar cek manual"}');
    lastManualAt = Date.now();
    runRound('manual');
    return send(res, 202, 'application/json', '{"ok":true}');
  }
  if (req.method === 'GET' && u.pathname === '/healthz') return send(res, 200, 'text/plain', 'ok');
  if (req.method === 'GET' && (u.pathname === '/history' || u.pathname === '/history.html')) {
    return send(res, 200, 'text/html; charset=utf-8', fs.readFileSync(path.join(PUBLIC_DIR, 'history.html')));
  }
  if (req.method === 'GET' && (u.pathname === '/' || u.pathname === '/index.html')) {
    return send(res, 200, 'text/html; charset=utf-8', fs.readFileSync(path.join(PUBLIC_DIR, 'index.html')));
  }
  send(res, 404, 'text/plain', 'Not found');
});

// ---------- start ----------
loadResults();
setInterval(compact, 3600 * 1000);
server.listen(PORT, HOST, () => {
  log(`Dashboard: http://${HOST}:${PORT}  | interval ${cfg.intervalMinutes || 5} menit | timeout ${TIMEOUT_MS}ms`);
  if (!DASH_USER) log('PERINGATAN: DASH_USER/DASH_PASS kosong — dashboard tanpa login');
  runRound('startup').then(scheduleNext);
});

process.on('SIGTERM', () => { log('Berhenti'); server.close(() => process.exit(0)); });
